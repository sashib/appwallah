
exports.EMPTY_FIND_RESULTS = "Didn\'t find any ideas";
exports.ADDED_IDEA = "Idea added!";

exports.ERROR_ADDING_IDEA = "Had trouble adding that idea";