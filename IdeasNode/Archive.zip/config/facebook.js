var facebook = {};

// Facebook Page Token for App
facebook.pageId = "267140500293954";
facebook.pageToken = "EAADXCiPJb3MBAO3vDGcguiMv9nzOfq71yrpl3L4PQ7bhXNuaZAioYZBx3d8JIOwOIfyNlqctts5hkqPWsqinMw6jwi4MCHlHkH6QidIYZBeLWR5qY8lGwwYsnXSiSw0BDjiaEbkoWZBwvFj2VM9IWxyl7fJHmyo0OwSK5nn9ygZDZD";
facebook.source = "facebook";
facebook.postUrl = "https://graph.facebook.com/v2.6/me/messages";

module.exports = facebook;